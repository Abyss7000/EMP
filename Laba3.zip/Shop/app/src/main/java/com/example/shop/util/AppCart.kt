package com.example.shop.util

import com.example.shop.model.ItemWithQuantity
import kotlinx.coroutines.flow.MutableStateFlow

object AppCart{
    var cart: MutableStateFlow<List<ItemWithQuantity>> = MutableStateFlow(listOf())
}