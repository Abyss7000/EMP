package com.example.shop.ui.screens.shop

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.shop.rep.AssortmentRepository

@Suppress("UNCHECKED_CAST")
class ShopViewModelFactory(private val rep: AssortmentRepository) :
    ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ShopViewModel(rep) as T
}