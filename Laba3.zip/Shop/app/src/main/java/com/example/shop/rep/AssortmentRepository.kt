package com.example.shop.rep

import com.example.shop.R
import com.example.shop.model.BYN
import com.example.shop.model.ItemElement
import java.util.UUID

object AssortmentRepository {
    val items = listOf(
        ItemElement(
            id = UUID.randomUUID(),
            name = "Bananas",
            price = BYN(5f),
            iconResId = R.drawable.banana
        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "M16",
            price = BYN(5000f),
            iconResId = R.drawable.m16
        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "Melon",
            price = BYN(7f),
            iconResId = R.drawable.melon

        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "EFT: Scam Edition",
            price = BYN(817.72f),
            iconResId = R.drawable.eft
        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "Pocket Gnome",
            price = BYN(1488f),
            iconResId = R.drawable.itpedia

        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "IPhone",
            price = BYN(404f),
            iconResId = R.drawable.iphone
        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "XBox",
            price = BYN(655f),
            iconResId = R.drawable.xbox

        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "Corona Extra 6-pack",
            price = BYN(30f),
            iconResId = R.drawable.corona_extra
        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "La Fuerza está con Cerveza Cristal",
            price = BYN(43434f),
            iconResId = R.drawable.la_fuerza_esta_con_cerveza_cristal

        ),
        ItemElement(
            id = UUID.randomUUID(),
            name = "Sphynx cat",
            price = BYN(700f),
            iconResId = R.drawable.sphynx
        ),
    )
}