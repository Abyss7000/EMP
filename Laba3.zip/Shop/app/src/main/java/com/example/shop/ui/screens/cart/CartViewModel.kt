package com.example.shop.ui.screens.cart

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.shop.model.BYN
import com.example.shop.model.ItemWithQuantity
import com.example.shop.util.AppCart
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

@OptIn(ExperimentalCoroutinesApi::class)
class CartViewModel() : ViewModel() {

    val uiState: StateFlow<CartState> = AppCart.cart.flatMapLatest { cart ->
        if (cart.isNotEmpty()) {
            flowOf(CartState.WithItems(cart))
        } else {
            flowOf(CartState.Empty)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(300),
        initialValue = CartState.Empty
    )


    fun calculateCart(cart: List<ItemWithQuantity>): BYN {
        val total = BYN(0f)
        cart.forEach { itemWithQuantity ->
            total += itemWithQuantity.itemElement.price * itemWithQuantity.itemsLeft
        }
        return total
    }

    fun clearCart(cart: MutableStateFlow<List<ItemWithQuantity>>) {
        cart.value = listOf()
    }

    sealed class CartState() {
        data class WithItems(val cart: List<ItemWithQuantity>) : CartState()
        data object Empty : CartState()
    }
}