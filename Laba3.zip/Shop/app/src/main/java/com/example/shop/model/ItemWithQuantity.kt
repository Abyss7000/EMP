package com.example.shop.model

data class ItemWithQuantity(
    val itemElement: ItemElement,
    var itemsLeft: Int
)
