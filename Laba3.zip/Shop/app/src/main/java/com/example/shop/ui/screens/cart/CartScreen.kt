package com.example.shop.ui.screens.cart

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.lifecycle.viewmodel.compose.viewModel
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.example.shop.R
import com.example.shop.model.ItemWithQuantity
import com.example.shop.ui.common.AlertOnPay
import com.example.shop.ui.screens.shop.ShopScreen
import com.example.shop.util.AppCart
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
class CartScreen : Screen {
    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow
        val viewModel: CartViewModel = viewModel()
        var readyToPay by remember {
            mutableStateOf(false)
        }
        val cart by AppCart.cart.collectAsState()
        val uiState by viewModel.uiState.collectAsState()
        val scope = rememberCoroutineScope()
        val snackBarHost = SnackbarHostState()

        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(text = stringResource(R.string.shop_name))
                    },
                    navigationIcon = {
                        IconButton(onClick = { navigator.push(ShopScreen()) }) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowLeft,
                                contentDescription = stringResource(R.string.cart_back)
                            )
                        }
                    }
                )
            },
            floatingActionButton = {
                if (uiState is CartViewModel.CartState.WithItems) {
                    Button(onClick = { readyToPay = true }) {
                        Text(text = stringResource(R.string.cart_buy))
                    }
                }
            },
            snackbarHost = {
                snackBarHost.currentSnackbarData?.let { Snackbar(snackbarData = it) }
            },
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ) { paddingValues ->
            when (uiState) {
                is CartViewModel.CartState.Empty -> {
                    Box(
                        modifier = Modifier
                            .padding(paddingValues)
                            .fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = stringResource(R.string.cart_empty),
                            style = MaterialTheme.typography.titleLarge,
                            textAlign = TextAlign.Center
                        )
                    }

                }

                is CartViewModel.CartState.WithItems -> {
                    if (readyToPay) {
                        AlertOnPay(
                            isAgreed = {
                                readyToPay = it
                            },
                            onConfirm = {
                                scope.launch {
                                    snackBarHost.showSnackbar(
                                        message = "Thank you for your order!",
                                        duration = SnackbarDuration.Short,
                                        withDismissAction = true
                                    )
                                }
                                viewModel.clearCart(AppCart.cart)
                            },
                            price = viewModel.calculateCart(cart = cart)
                        )
                    }
                    LazyColumn(
                        modifier = Modifier
                            .padding(paddingValues),
                        contentPadding = PaddingValues(dimensionResource(R.dimen.content_default_padding))
                    ) {
                        items(cart) { item ->
                            ItemInCart(
                                modifier = Modifier
                                    .padding(dimensionResource(R.dimen.content_default_padding)),
                                item = item,
                            )
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun ItemInCart(
        modifier: Modifier = Modifier,
        item: ItemWithQuantity,
    ) {
        ElevatedCard(
            modifier = modifier
                .fillMaxWidth()
        ) {
            Text(
                modifier = Modifier
                    .padding(dimensionResource(R.dimen.content_default_padding))
                    .fillMaxWidth(),
                text = item.itemElement.name,
                style = MaterialTheme.typography.labelLarge,
            )
            ItemCardBody(
                modifier = Modifier,
                item = item
            )
        }
    }

    @Composable
    private fun ItemCardBody(
        modifier: Modifier = Modifier,
        item: ItemWithQuantity
    ) {
        Row(
            modifier = modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Image(
                modifier = Modifier
                    .padding(dimensionResource(R.dimen.content_default_padding))
                    .heightIn(
                        min = dimensionResource(R.dimen.min_image_size),
                        max = dimensionResource(R.dimen.max_image_height)
                    )
                    .widthIn(
                        min = dimensionResource(R.dimen.min_image_size),
                        max = dimensionResource(R.dimen.max_image_width)
                    )
                    .border(
                        width = dimensionResource(R.dimen.border_width),
                        color = MaterialTheme.colorScheme.onBackground,
                        shape = MaterialTheme.shapes.medium
                    )
                    .clip(MaterialTheme.shapes.medium),
                painter = painterResource(item.itemElement.iconResId),
                contentDescription = item.itemElement.name
            )
            Column {
                Text(
                    modifier = Modifier
                        .padding(dimensionResource(R.dimen.content_default_padding)),
                    text = stringResource(R.string.shop_price, item.itemElement.price.value),
                    style = MaterialTheme.typography.labelLarge,
                    textAlign = TextAlign.Center
                )
                Text(
                    modifier = Modifier
                        .padding(dimensionResource(R.dimen.content_default_padding)),
                    text = stringResource(R.string.shop_left, item.itemsLeft),
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}