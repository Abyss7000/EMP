package com.example.shop.model

import androidx.compose.runtime.Immutable
import com.example.shop.R
import java.util.UUID

@Immutable
data class ItemElement(
    val id: UUID,
    val name: String,
    val price: BYN,
    val iconResId: Int = R.drawable.placeholder
)
