package com.example.shop.model

data class BYN(
    var actualValue: Float
) {
    val value: String
        get() = "$actualValue BYNOV"

    operator fun plusAssign(other: BYN) {
        this.actualValue += other.actualValue
    }

    operator fun times(itemsLeft: Int): BYN {
        return BYN(this.actualValue*itemsLeft)
    }
}

