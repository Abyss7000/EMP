package com.example.shop.ui.common

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.example.shop.R
import com.example.shop.model.BYN

@Composable
fun AlertOnPay(
    isAgreed: (Boolean) -> Unit,
    onConfirm: () -> Unit,
    price: BYN
) {
    AlertDialog(
        onDismissRequest = { isAgreed(false) },
        confirmButton = {
            TextButton(onClick = {
                isAgreed(false)
                onConfirm()
            }) {
                Text(text = stringResource(R.string.cart_buy))
            }
        },
        title = {
            Text(
                text = stringResource(R.string.cart_header),
            )
        },
        text = {
            Text(
                text = stringResource(R.string.cart_buy_dialog_text, price.value)
            )
        }
    )
}