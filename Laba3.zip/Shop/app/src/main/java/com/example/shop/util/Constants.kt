package com.example.shop.util

const val DEFAULT_QUANTITY = 15
const val DEFAULT_ERROR = 5