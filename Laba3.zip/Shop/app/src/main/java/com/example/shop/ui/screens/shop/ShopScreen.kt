@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.shop.ui.screens.shop

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.example.shop.R
import com.example.shop.model.BYN
import com.example.shop.model.ItemElement
import com.example.shop.model.ItemWithQuantity
import com.example.shop.rep.AssortmentRepository
import com.example.shop.ui.common.AlertOnPay
import com.example.shop.ui.screens.cart.CartScreen
import kotlinx.coroutines.launch
import java.util.UUID

class ShopScreen : Screen {
    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow
        val viewModel: ShopViewModel = viewModel(
            factory = ShopViewModelFactory(AssortmentRepository)
        )
        val items by viewModel.items.collectAsState()
        var isLastItemWarning by remember {
            mutableStateOf(false)
        }
        var readyToPay by remember {
            mutableStateOf(false)
        }
        val hotItem by viewModel.itemOnHotBuy.collectAsState()
        val scope = rememberCoroutineScope()
        val snackBarHost = SnackbarHostState()
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(text = stringResource(R.string.shop_name))
                    },
                    actions = {
                        IconButton(onClick = { navigator.push(CartScreen()) }) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = stringResource(R.string.shop_buy)
                            )
                        }
                    }
                )
            },
            snackbarHost = {
                snackBarHost.currentSnackbarData?.let { Snackbar(snackbarData = it) }
            },
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ) { paddingValues ->
            if (isLastItemWarning) {
                AlertOnEmpty(isLastItemWarning = {
                    isLastItemWarning = it
                })
            }
            if (readyToPay) {
                AlertOnPay(
                    isAgreed = {
                        readyToPay = it
                    },
                    onConfirm = {
                        viewModel.hotBuy(
                            onLastItem = { isLast ->
                                isLastItemWarning = isLast
                            }
                        )
                        if (!isLastItemWarning){
                            scope.launch {
                                snackBarHost.showSnackbar(
                                    message = "Thank you for your order!",
                                    duration = SnackbarDuration.Short,
                                    withDismissAction = true
                                )
                            }
                        }
                    },
                    price = hotItem!!.itemElement.price
                )
            }
            LazyColumn(
                modifier = Modifier
                    .padding(paddingValues),
                contentPadding = PaddingValues(dimensionResource(R.dimen.content_default_padding))
            ) {
                items(items) { item ->
                    Item(
                        modifier = Modifier
                            .padding(dimensionResource(R.dimen.content_default_padding)),
                        item = item,
                        onBuy = {
                            readyToPay = true
                            viewModel.onHotBuy(item)
                        },
                        onAddToCart = {
                            viewModel.updateAndAddToCart(
                                itemId = item.itemElement.id,
                                onLastItem = { isLast ->
                                    isLastItemWarning = isLast
                                }
                            )
                        }
                    )
                }
            }
        }
    }

    @Composable
    private fun AlertOnEmpty(isLastItemWarning: (Boolean) -> Unit) {
        AlertDialog(
            onDismissRequest = { isLastItemWarning(false) },
            confirmButton = {
                TextButton(onClick = { isLastItemWarning(false) }) {
                    Text(text = stringResource(R.string.shop_confirm_button))
                }
            },
            title = {
                Text(
                    text = stringResource(R.string.shop_empty_dialog_title),
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.shop_empty_dialog_text)
                )
            }
        )
    }

    @Composable
    private fun Item(
        modifier: Modifier = Modifier,
        item: ItemWithQuantity,
        onBuy: () -> Unit,
        onAddToCart: () -> Unit
    ) {
        ElevatedCard(
            modifier = modifier
                .fillMaxWidth()
        ) {
            Text(
                modifier = Modifier
                    .padding(dimensionResource(R.dimen.content_default_padding))
                    .fillMaxWidth(),
                text = item.itemElement.name,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            ItemCardBody(
                modifier = Modifier,
                item = item
            )
            ButtonRow(
                modifier = Modifier,
                onBuy = onBuy,
                onAddToCart = onAddToCart
            )
        }
    }

    @Composable
    private fun ItemCardBody(
        modifier: Modifier = Modifier,
        item: ItemWithQuantity
    ) {
        Row(
            modifier = modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Image(
                modifier = Modifier
                    .padding(dimensionResource(R.dimen.content_default_padding))
                    .heightIn(
                        min = dimensionResource(R.dimen.min_image_size),
                        max = dimensionResource(R.dimen.max_image_height)
                    )
                    .widthIn(
                        min = dimensionResource(R.dimen.min_image_size),
                        max = dimensionResource(R.dimen.max_image_width)
                    )
                    .border(
                        width = dimensionResource(R.dimen.border_width),
                        color = MaterialTheme.colorScheme.onBackground,
                        shape = MaterialTheme.shapes.medium
                    )
                    .clip(MaterialTheme.shapes.medium),
                painter = painterResource(item.itemElement.iconResId),
                contentDescription = item.itemElement.name,
                contentScale = ContentScale.Crop
            )
            Column {
                Text(
                    modifier = Modifier
                        .padding(dimensionResource(R.dimen.content_default_padding)),
                    text = stringResource(R.string.shop_price, item.itemElement.price.value),
                    style = MaterialTheme.typography.labelLarge,
                    textAlign = TextAlign.Center
                )
                Text(
                    modifier = Modifier
                        .padding(dimensionResource(R.dimen.content_default_padding)),
                    text = stringResource(R.string.shop_left, item.itemsLeft),
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    @Composable
    private fun ButtonRow(
        modifier: Modifier = Modifier,
        onAddToCart: () -> Unit,
        onBuy: () -> Unit
    ) {
        Row(
            modifier = modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            OutlinedButton(
                modifier = Modifier
                    .padding(dimensionResource(R.dimen.content_default_padding)),
                onClick = remember { { onAddToCart() } }
            ) {
                Text(
                    text = stringResource(R.string.shop_add_to_cart),
                    style = MaterialTheme.typography.labelMedium
                )
            }
            Button(
                modifier = Modifier
                    .padding(dimensionResource(R.dimen.content_default_padding)),
                onClick = remember { { onBuy() } },
            ) {
                Text(
                    text = stringResource(R.string.shop_buy_now),
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }

    @Preview
    @Composable
    private fun ItemPreview() {
        Item(
            modifier = Modifier
                .padding(dimensionResource(R.dimen.content_default_padding)),
            item = testItem,
            onBuy = {},
            onAddToCart = {}
        )
    }

    private val testItem = ItemWithQuantity(
        itemsLeft = 40,
        itemElement = ItemElement(
            id = UUID.randomUUID(),
            name = "Test",
            price = BYN(56660f),
            iconResId = R.drawable.itpedia
        )
    )
}

