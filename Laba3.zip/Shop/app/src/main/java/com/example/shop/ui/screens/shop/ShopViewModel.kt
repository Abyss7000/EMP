package com.example.shop.ui.screens.shop

import androidx.lifecycle.ViewModel
import com.example.shop.model.ItemWithQuantity
import com.example.shop.rep.AssortmentRepository
import com.example.shop.util.AppCart.cart
import com.example.shop.util.DEFAULT_ERROR
import com.example.shop.util.DEFAULT_QUANTITY
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.random.Random
import kotlin.random.nextInt

class ShopViewModel(
    repository: AssortmentRepository
) : ViewModel() {
    private val _items = MutableStateFlow(
        repository.items.map {
            ItemWithQuantity(it, randomize())
        }
    )
    val items: StateFlow<List<ItemWithQuantity>> = _items.asStateFlow()

    private val _itemOnHotBuy = MutableStateFlow<ItemWithQuantity?>(null)
    val itemOnHotBuy: StateFlow<ItemWithQuantity?> = _itemOnHotBuy.asStateFlow()

    fun onHotBuy(hotItem: ItemWithQuantity) {
        _itemOnHotBuy.value = hotItem
    }

    fun hotBuy(onLastItem: (Boolean) -> Unit) {
        itemOnHotBuy.value?.let { hotItem ->
            updateItems(
                itemId = hotItem.itemElement.id,
                onLastItem = onLastItem,
                onFindItem = {}
            )
        }
    }

    fun updateAndAddToCart(
        itemId: UUID,
        onLastItem: (Boolean) -> Unit,
    ) {
        updateItems(
            onLastItem = onLastItem,
            itemId = itemId,
            onFindItem = {
                addToCart(it)
            }
        )

    }

    private fun updateItems(
        itemId: UUID,
        onLastItem: (Boolean) -> Unit,
        onFindItem: (ItemWithQuantity) -> Unit
    ) {
        _items.value = _items.value.map { itemWithQuantity ->
            if (itemWithQuantity.itemElement.id == itemId) {
                if (itemWithQuantity.itemsLeft == 0) {
                    onLastItem(true)
                    return
                }
                itemWithQuantity.copy(itemsLeft = itemWithQuantity.itemsLeft - 1).also {
                    onFindItem(it)
                }
            } else {
                itemWithQuantity
            }
        }
    }

    private fun addToCart(addedItem: ItemWithQuantity?) {
        if (addedItem != null) {
            val newItemWithQuantity =
                addedItem.copy(itemsLeft = addedItem.itemsLeft - 1)
            val itemInCart = cart.value.find { it.itemElement.id == addedItem.itemElement.id }
            if (itemInCart != null) {
                cart.value = cart.value.map { cartItem ->
                    if (cartItem.itemElement.id == addedItem.itemElement.id) {
                        cartItem.copy(itemsLeft = cartItem.itemsLeft + 1)
                    } else {
                        cartItem
                    }
                }
            } else {
                cart.value += ItemWithQuantity(newItemWithQuantity.itemElement, 1)
            }
        }
    }

    private fun randomize(): Int {
        val range = (DEFAULT_QUANTITY - DEFAULT_ERROR)..(DEFAULT_QUANTITY + DEFAULT_ERROR)
        return Random.nextInt(range)
    }
}
